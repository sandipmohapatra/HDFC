package in.nareshit.raghu.service;

import in.nareshit.raghu.model.User;
//ctrl+shift+O

public interface IUserService {

	public Integer saveUser(User user);
}
