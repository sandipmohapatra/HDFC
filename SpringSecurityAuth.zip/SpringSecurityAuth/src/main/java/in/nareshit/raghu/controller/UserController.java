package in.nareshit.raghu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import in.nareshit.raghu.model.User;
import in.nareshit.raghu.service.IUserService;
import in.nareshit.raghu.util.EmailUtil;

@Controller
public class UserController {
	@Autowired
	private IUserService service;
	@Autowired
	private EmailUtil emailUtil;

	//1. Show Register page
	@GetMapping("/reg")
	public String showReg() {
		return "UserRegister";
	}
	
	//2. Read Form data for save operation
	@PostMapping("/insert")
	public String saveUser(
			@ModelAttribute User user,
			Model model)
	{
		Integer id = service.saveUser(user);
		String msg ="User '"+id+"' saved";
		
		if(id!=null) {
			String text = "User : "+ user.getName() +" , created with roles:"+user.getRoles();
			boolean sent = emailUtil.send(user.getEmail(), "WELCOME TO USER!", text);
			if(sent)
				msg+=", Email also sent :)";
			else 
				msg+=", Email sending Failed :(";
		}
		
		model.addAttribute("message", msg);
		return "UserRegister";
	}
	
	@GetMapping("/showlog")
	public String showLogin() {
		return "UserLogin";
	}
}
