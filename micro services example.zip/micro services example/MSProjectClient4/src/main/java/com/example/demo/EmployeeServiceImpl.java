package com.example.demo;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements IEmployeeService 
{
@Autowired
private EmployeeRepository repo;
Employee x=null;

	@Override
	public Integer saveEmployee(Employee c) {
		c=repo.save(c);
		return c.getEid();
	}

	@Override
	public List<Employee> getAllEmployee() {
		List x=(List) repo.findAll();
		return x;
	}

	@Override
	public Employee getOneEmployee(Integer id) {
	Optional<Employee> opt=repo.findById(id);
		return opt.get();
	}

}
