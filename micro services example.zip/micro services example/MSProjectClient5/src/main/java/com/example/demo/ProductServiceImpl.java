package com.example.demo;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements IProductService 
{
@Autowired
private ProductRepository repo;
Product x=null;

	@Override
	public Integer saveProduct(Product c) {
		c=repo.save(c);
		return c.getPid();
	}

	@Override
	public List<Product> getAllProduct() {
		List x=(List) repo.findAll();
		return x;
	}

	@Override
	public Product getOneProduct(Integer id) {
	Optional<Product> opt=repo.findById(id);
		return opt.get();
	}

}
