package com.example.demo;

import java.util.List;

public interface IStudentService 
{
public Integer saveStudent(Student c);
public List<Student> getAllStudent();
public Student getOneStudent(Integer id);
}
