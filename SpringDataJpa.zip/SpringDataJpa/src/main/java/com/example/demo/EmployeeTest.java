package com.example.demo;

import java.util.Arrays;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class EmployeeTest implements CommandLineRunner
{
@Autowired
private EmployeeRepository repo;

	@Override
	public void run(String... args) throws Exception
	{
		
		  repo.save(new Employee("sandip k",3000.30));
		  repo.save(new Employee("madhu r",3000.30)); 
		  repo.save(new Employee("shubham m",3000.30));
		  repo.save(new Employee("trupti",3000.30)); 
		  repo.save(new Employee(4,"trupti p",37800.30));
		  
		  repo.saveAll(Arrays.asList( new Employee("Kiran",35000.89), 
				  new Employee("Niraj",35000.89), 
				  new Employee("sunil",35000.89), 
				  new Employee("anil",35000.89), 
				  new Employee("anil",45000.89) ));
		 
		boolean exist=repo.existsById(8);
	System.out.println("This is test.............."+exist);
	
	//repo.deleteById(5);
    //repo.deleteAll();
	Optional<Employee> opt=repo.findById(6);  
	if(opt.isPresent())
	{
		Employee s=opt.get();
		System.out.println(s);
	}
	repo.findAll().forEach(System.out::println);
	repo.findAllById(Arrays.asList(5,6,7,8)).forEach(System.out::println);
	
	}
	}



