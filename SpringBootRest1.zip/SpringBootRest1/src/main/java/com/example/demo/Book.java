package com.example.demo;

public class Book 
{
public Book() {
		super();
	}
private long bookid;
private String title;
private double price;
public long getBookid() {
	return bookid;
}
public void setBookid(long bookid) {
	this.bookid = bookid;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public String getAuthorname() {
	return Authorname;
}
public void setAuthorname(String authorname) {
	Authorname = authorname;
}
private String Authorname;
public Book(long bookid, String title, double price, String authorname) {
	super();
	this.bookid = bookid;
	this.title = title;
	this.price = price;
	Authorname = authorname;
}
@Override
public String toString() {
	return "Book [bookid=" + bookid + ", title=" + title + ", price=" + price + ", Authorname=" + Authorname + "]";
}

}