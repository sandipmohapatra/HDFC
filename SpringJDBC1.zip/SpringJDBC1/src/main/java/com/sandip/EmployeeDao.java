package com.sandip;

import org.springframework.jdbc.core.JdbcTemplate;
public class EmployeeDao 
{
private JdbcTemplate jdbcTemplate;

public JdbcTemplate getJdbcTemplate() {
	return jdbcTemplate;
}

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}
public int saveEmployee(Employee e)
{
	String xyz="insert into employee1 values(' "+e.getId()+ " ',' "+e.getName()+" ',' "+e.getSalary()+" ')";
	return jdbcTemplate.update(xyz);	
}

public int updateEmployee(Employee e)
{
	String xyz="update employee1 set name=' "+e.getName()+" ',salary=' "+e.getSalary() +" ' where id=' "+e.getId()+" ' ";
				return jdbcTemplate.update(xyz);	
}

public int deleteEmployee(Employee e)
{
	String xyz="delete from employee1 where id=' "+e.getId()+" ' ";
	return jdbcTemplate.update(xyz);	
}

}
